package programa2animales;

abstract public class Programa2Animales {
    public String nombre;
    private Integer edad;
    
    public Programa2Animales(String nombre){
       this.nombre=nombre;
    } 
    
    public Programa2Animales(){};
    
    public Integer getedad(){
      return edad;
    }
    
    public void setedad(Integer edad){
    this.edad= edad;
    }
    
    abstract public void hacerruido();
    
    public static void main(String[] args) {
        // Puedes agregar aquí la lógica que desees para probar la clase Programa2Animales
        System.out.println("Ejecutando la clase Programa2Animales");
    }
}