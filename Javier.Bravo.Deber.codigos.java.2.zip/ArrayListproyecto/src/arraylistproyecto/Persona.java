package arraylistproyecto;
public class Persona {
    private int num;
    private String nombre;


    public Persona() {
    }

    public Persona(int num, String nombre){
        this.num = num;
        this.nombre = nombre;
  
    }
    public int getNum() {
        return num;
    }
    public void setNum(int num) {
        this.num = num;
    }

    public String getNombre() {
        return nombre;
    }

}