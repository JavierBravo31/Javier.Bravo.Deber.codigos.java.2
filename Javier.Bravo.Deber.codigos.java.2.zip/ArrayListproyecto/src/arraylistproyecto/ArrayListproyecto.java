package arraylistproyecto;

import java.util.ArrayList;
import java.util.List;

public class ArrayListproyecto {

    public static void main(String[] args) {
    
        List<Persona>lista = new ArrayList<Persona> ();
        lista.add(new Persona(1,"Yaneila"));
        lista.add(new Persona(2,"Javier"));
        lista.add(new Persona(3,"Fabricio"));
        lista.add(new Persona(4,"Angie"));
        lista.add(new Persona(5,"Jhon"));
        lista.add(new Persona(6,"Jose"));
        
        System.out.println("--FOR--");
        for (int i=0; i<lista.size(); i++){
            System.out.println("grupo7: " + lista.get(i).getNombre());
            
        }
        System.out.println("--FOREACH--");
        for (Persona perso:lista) {
            System.out.println("grupo7: " + perso.getNombre());
        }
        
    }
}


