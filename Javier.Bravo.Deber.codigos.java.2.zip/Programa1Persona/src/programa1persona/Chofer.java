
package programa1persona;
//Javier Bravo
import java.util.Scanner;

public class Chofer extends Programa1Persona{
    public String placa;
    public String codigotaxi;
    
    public Chofer(String nombre, Integer edad,String placa,String codigotaxi){
            super(nombre, edad);
            this.placa= placa;
            this.codigotaxi= codigotaxi;
    }
    
    public Chofer(){};
    
    @Override
    public void cedula(){
   Scanner entrada= new Scanner(System.in);
       int cedula;
       
       System.out.print("Digite la cedula  ");
       cedula= entrada.nextInt();
       
       System.out.println("El numero de cedula es  " +cedula );
    }
    
    public void aceptarcarrera(){
    System.out.println("El Chofer ha aceptado la carrera");
    }
    
    public void cancelarcarrera(){
    System.out.println("El chofer ha cancelado la carrera");
    }
    
    public void placa(){
    Scanner entrada= new Scanner(System.in);
       String placa;
       
       System.out.print("Digite la placa del taxi ");
       placa= entrada.next();
       
       System.out.println(placa +"La placa del carro es  " );
    
    }
}
