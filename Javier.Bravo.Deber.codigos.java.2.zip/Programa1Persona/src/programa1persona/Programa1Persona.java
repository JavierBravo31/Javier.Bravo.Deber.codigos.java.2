
package programa1persona;
//Javier Bravo
abstract public class Programa1Persona {
    public String nombre;
    public Integer edad;
    private Integer cedula;
    
    public Programa1Persona(String nombre,Integer edad) {
        this.nombre= nombre;
        this.edad= edad;
    }
    
    public Programa1Persona(){};

    public Integer getcedula(){
       return cedula;
       
    }
    public void setcedula(Integer cedula){
       this.cedula= cedula;
       
    }
    
    abstract public void cedula();
}
