
package programa1persona;
import java.util.Scanner;
//Javier Bravo
public class Pasajero extends Programa1Persona{
    public Integer id;
    public Pasajero(String nombre, Integer edad,Integer id){
            super(nombre, edad);
            this.id= id;
    }
    
    public Pasajero(){};
    

    @Override
    public void cedula(){
    Scanner entrada= new Scanner(System.in);
       int cedula;
       
       System.out.print("Escribir su numero de cedula  ");
       cedula= entrada.nextInt();
       
       System.out.println("Su numero de cedula es  " +cedula );
    }
    
    public void pedirtaxi(){
    System.out.println("El pasajero esta solicitando un taxi");
    }
        public void aceptartaxi() {
    System.out.println("El pasajero esta aceptando el taxi"); 
    }
    public void cancelartaxi(){
    System.out.println("El pasajero esta cancelando el taxi");
    }
}